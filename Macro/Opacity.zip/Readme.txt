    - MacOS: 
        - All users: /Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion\Macros
        - Specific user: /Users/<UserName>/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion\Macros

    - Windows: 
        - All users: C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Macros
		- Specific user: C:\Users\<UserName>\AppData\Roaming\Blackmagic Design\DaVinci Resolve\Support\Fusion\Macros