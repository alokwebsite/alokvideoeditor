# AutoFileOrganizer — DaVinci Resolve Plugin

Automatically organizes every clip in your Media Pool into named bins
based on file type — including dedicated bins for Timelines and Compound Clips.

---

## What It Does

When you run it, the script:

1. Scans all clips in the Media Pool (including sub-folders)
2. Detects each clip's category — **by clip type first, then file extension**
3. Creates bins if they don't already exist:
   - 📁 Timelines
   - 📁 Compound Clips
   - 📁 Video
   - 📁 Audio
   - 📁 Images
   - 📁 Subtitles
   - 📁 Documents
   - 📁 Other
4. Moves every clip into the correct bin
5. Prints a full report in the Console

---

## How Timeline & Compound Clip Detection Works

DaVinci Resolve exposes a `Type` property on every Media Pool clip.
This script reads that property **before** looking at the file extension:

| `Type` value | Goes to bin |
|---|---|
| `"Timeline"` | 📁 Timelines |
| `"Compound"` | 📁 Compound Clips |
| `"Video"` / extension match | 📁 Video |
| `"Audio"` / extension match | 📁 Audio |
| `"Still"` / extension match | 📁 Images |
| *(unmatched extension)* | 📁 Other |

This means Timelines and Compound Clips will **never** end up in 📁 Other.

---

## Installation

### Step 1 — Copy the script

Copy `AutoFileOrganizer.lua` into the DaVinci Resolve Scripts folder:

| OS | Path |
|---|---|
| Windows | `%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility\` |
| macOS | `~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/` |
| Linux | `~/.local/share/DaVinciResolve/Fusion/Scripts/Utility/` |

> Create the `Utility` folder if it does not exist.

### Step 2 — Run the script

Inside DaVinci Resolve:

```
Workspace  →  Scripts  →  Utility  →  AutoFileOrganizer
```

---

## Customizing Bin Names

Open `AutoFileOrganizer.lua` and edit the `CONFIG.bins` table:

```lua
bins = {
  video    = "📁 Video",
  audio    = "📁 Audio",
  image    = "📁 Images",
  srt      = "📁 Subtitles",
  doc      = "📁 Documents",
  timeline = "📁 Timelines",       -- ← rename as you like
  compound = "📁 Compound Clips",  -- ← rename as you like
  other    = "📁 Other",
},
```

---

## Notes

- **Non-destructive** — only moves clips inside the Media Pool. No files on disk are touched.
- **Idempotent** — safe to run multiple times. Clips already in the right bin stay there.
- Works with DaVinci Resolve 17, 18, and 19.
