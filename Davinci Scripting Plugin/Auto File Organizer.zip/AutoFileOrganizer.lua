--[[
  AutoFileOrganizer.lua
  DaVinci Resolve Script — Auto File Organizer
  
  Automatically organizes all clips in the Media Pool into
  named bins based on file type and clip type.

  Supported bins:
    📁 Video, 📁 Audio, 📁 Images, 📁 Subtitles,
    📁 Documents, 📁 Timelines, 📁 Compound Clips, 📁 Other

  Install:
    Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility\
    macOS:   ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/
    Linux:   ~/.local/share/DaVinciResolve/Fusion/Scripts/Utility/

  Usage: Workspace > Scripts > Utility > AutoFileOrganizer
--]]

-----------------------------------------------------------
-- CONFIG
-----------------------------------------------------------

local CONFIG = {

  -- Bin names (customize to your preference)
  bins = {
    video    = "📁 Video",
    audio    = "📁 Audio",
    image    = "📁 Images",
    srt      = "📁 Subtitles",
    doc      = "📁 Documents",
    timeline = "📁 Timelines",
    compound = "📁 Compound Clips",
    design   = "📁 Design Files",
    other    = "📁 Other",
  },

  -- Extensions → bin key (used for regular file-based clips)
  extensions = {
    -- Video
    mp4="video", mov="video", mxf="video", avi="video",
    mkv="video", r3d="video", braw="video", dpx="video",
    mts="video", m2t="video", m2ts="video", wmv="video",
    flv="video", webm="video", hevc="video",
    mp2="video", mpg="video", mpeg="video", m4v="video",

    -- Audio
    wav="audio", mp3="audio", aiff="audio", aif="audio",
    flac="audio", m4a="audio", ogg="audio", aac="audio",
    ac3="audio", eac3="audio",

    -- Image / Still
    png="image", jpg="image", jpeg="image", tiff="image",
    tif="image", bmp="image",
    exr="image", hdr="image", tga="image",
    gif="image", webp="image", heic="image", raw="image",
    cr2="image", nef="image", arw="image",

    -- Design Files
    psd="design", psb="design", af="design", afphoto="design", afdesign="design", afpub="design",

    -- Subtitles
    srt="srt", vtt="srt", ass="srt", ssa="srt",

    -- Documents
    pdf="doc", txt="doc", xlsx="doc", csv="doc", docx="doc",
  },

  -- Skip creating a bin if no clips of that type exist
  skip_empty_bins = true,
}

-----------------------------------------------------------
-- HELPERS
-----------------------------------------------------------

local function get_extension(filename)
  local ext = filename:match("%.([^%.]+)$")
  return ext and ext:lower() or ""
end

-- Detect the bin key for a clip.
-- Priority: clip type check (timeline / compound) FIRST,
-- then fall back to file extension.
local function get_bin_key(clip)
  -- GetClipProperty returns a table of all properties
  local props = clip:GetClipProperty()
  if not props then
    return "other"
  end

  -- "Type" property values from the Resolve API:
  --   "Timeline"        → a timeline item in the media pool
  --   "Compound"        → a compound clip
  --   "Video"           → regular video clip
  --   "Audio"           → regular audio clip
  --   "Still"           → still image
  --   "Generator"       → Fusion generator / solid color
  local clip_type = props["Type"] or ""

  if clip_type == "Timeline" then
    return "timeline"
  end

  if clip_type == "Compound" then
    return "compound"
  end

  -- For file-based clips, use the extension
  local filename = props["File Name"] or clip:GetName() or ""
  local ext = get_extension(filename)
  return CONFIG.extensions[ext] or "other"
end

-----------------------------------------------------------
-- MEDIA POOL UTILITIES
-----------------------------------------------------------

-- Recursively collect all clips from a folder and sub-folders.
-- Skips our own auto-organizer bins to avoid re-scanning on
-- subsequent runs (clips already sorted stay sorted).
local function collect_clips(folder, our_bin_names, results)
  results = results or {}

  local clips = folder:GetClipList()
  for _, clip in ipairs(clips) do
    table.insert(results, clip)
  end

  local sub_folders = folder:GetSubFolderList()
  for _, sub in ipairs(sub_folders) do
    collect_clips(sub, our_bin_names, results)
  end

  return results
end

-- Find a bin by exact name (top-level children of parent_folder only)
local function find_bin(parent_folder, name)
  for _, sub in ipairs(parent_folder:GetSubFolderList()) do
    if sub:GetName() == name then
      return sub
    end
  end
  return nil
end

-- Get existing bin or create a new one
local function get_or_create_bin(media_pool, parent_folder, name)
  local existing = find_bin(parent_folder, name)
  if existing then
    return existing, false
  end
  local new_bin = media_pool:AddSubFolder(parent_folder, name)
  return new_bin, true
end

-----------------------------------------------------------
-- MAIN
-----------------------------------------------------------

local function run()
  local resolve     = Resolve()
  local project     = resolve:GetProjectManager():GetCurrentProject()

  if not project then
    print("[AutoFileOrganizer] ERROR: No project is currently open.")
    return
  end

  local media_pool   = project:GetMediaPool()
  local root_folder  = media_pool:GetRootFolder()

  print("")
  print("=================================================")
  print("  AutoFileOrganizer — DaVinci Resolve Plugin")
  print("  Project: " .. project:GetName())
  print("=================================================")

  -- Build a set of our bin names so we can report on them
  local our_bin_names = {}
  for _, name in pairs(CONFIG.bins) do
    our_bin_names[name] = true
  end

  -- Collect every clip in the project
  local all_clips = collect_clips(root_folder, our_bin_names, {})
  print(string.format("[Scan] Found %d clip(s) in media pool.", #all_clips))

  if #all_clips == 0 then
    print("[Done] Media pool is empty — nothing to organize.")
    return
  end

  -- Categorize
  local categorized = {}
  for key in pairs(CONFIG.bins) do
    categorized[key] = {}
  end

  for _, clip in ipairs(all_clips) do
    local key = get_bin_key(clip)
    if not categorized[key] then
      categorized[key] = {}
    end
    table.insert(categorized[key], clip)
  end

  -- Print summary
  print("")
  print("[Summary] Detected clip categories:")
  local order = {"timeline","compound","video","audio","image","design","srt","doc","other"}
  for _, key in ipairs(order) do
    local clips = categorized[key] or {}
    if #clips > 0 then
      print(string.format("  %-14s → %2d clip(s)   bin: %s",
        key, #clips, CONFIG.bins[key]))
    end
  end

  -- Create bins and move clips
  print("")
  print("[Organizing] Moving clips into bins...")

  local moved_total = 0
  local bins_created = 0

  for _, key in ipairs(order) do
    local clips = categorized[key] or {}
    if #clips > 0 or not CONFIG.skip_empty_bins then
      local bin_name = CONFIG.bins[key]
      local bin, was_created = get_or_create_bin(media_pool, root_folder, bin_name)

      if bin then
        if was_created then
          print(string.format("  [+] Created bin: %s", bin_name))
          bins_created = bins_created + 1
        else
          print(string.format("  [=] Using existing bin: %s", bin_name))
        end

        if #clips > 0 then
          local ok = media_pool:MoveClips(clips, bin)
          if ok then
            print(string.format("      Moved %d clip(s) → %s", #clips, bin_name))
            moved_total = moved_total + #clips
          else
            print(string.format("  [!] Warning: Could not move some clips to %s", bin_name))
          end
        end
      else
        print(string.format("  [!] ERROR: Could not create bin '%s'", bin_name))
      end
    end
  end

  -- Final report
  print("")
  print("=================================================")
  print(string.format("  Done!  Bins created: %d  |  Clips moved: %d",
    bins_created, moved_total))
  print("=================================================")
  print("")
end

run()
