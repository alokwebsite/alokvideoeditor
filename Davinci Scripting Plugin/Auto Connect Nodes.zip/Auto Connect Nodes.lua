-- Auto Connect Nodes Script with UI for DaVinci Resolve / Fusion

local ui = fusion.UIManager
local disp = bmd.UIDispatcher(ui)
local WIN_W, WIN_H = 440, 250

local TARGET_MODE = "MediaOut"

local ON_STYLE = [[
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
        stop:0 #0D3322, stop:1 #0F4428);
    color:#40E090; font-weight:700; font-size:11px;
    border:1px solid #1E7A45;
    border-radius:3px; padding:4px 14px;
]]
local OFF_STYLE = [[
    background:#131320;
    color:#2E3E4E; font-size:11px;
    border:1px solid #1C1C2C;
    border-radius:3px; padding:4px 14px;
]]

local win = disp:AddWindow({
    ID = "AutoConnectWin",
    WindowTitle = "Auto Connect Nodes",
    Geometry = { 200, 200, WIN_W, WIN_H },
    Spacing = 0,
    
    ui:VGroup{
        Spacing = 0,
        StyleSheet = "background:#1A1A24;",

        -- ── HEADER ──
        ui:HGroup{
            StyleSheet = "background:#12121E; padding: 9px 12px 7px 12px;",
            ui:Label{
                Text = "AUTO CONNECT NODES",
                StyleSheet = [[
                    font-family: 'Segoe UI', Arial, sans-serif;
                    font-size: 12px; font-weight: 700;
                    letter-spacing: 3px; color: #FFD166;
                ]],
            },
            ui:HGap(0, 1),
            ui:Label{
                Text = "Alok Video Editor",
                Alignment = { AlignRight = true },
                StyleSheet = "font-size:9px; color:#383850;",
            },
        },
        ui:Label{
            Text = "",
            StyleSheet = "background:#FFD166; min-height:2px; max-height:2px;",
        },
        
        ui:HGroup{
            StyleSheet = "background:#0F1525; padding: 4px 12px;",
            ui:Label{
                Text = "Pairs: 3 BG + 3 ImagePlanes | Multi: 3 Text+ + 1 MultiMerge",
                StyleSheet = "color:#445566; font-size:10px;",
            },
        },
        
        -- ── TOGGLE BAR ──
        ui:HGroup{
            StyleSheet = "background:#161626; padding: 6px 12px 3px 12px;",
            ui:Button{
                ID = "BtnTargetToggle",
                Text = "—  Target: MediaOut",
                StyleSheet = OFF_STYLE,
            },
            ui:HGap(0, 1),
        },

        -- ── LOG (scrollable text area) ──
        ui:TextEdit{
            ID       = "Log",
            ReadOnly = true,
            Text     = "\nSelect nodes and click 'Connect Now'.",
            StyleSheet = [[
                background:#0A0A14;
                color:#55EEBB;
                font-family: Consolas, monospace;
                font-size: 11px;
                border: none;
                min-height: 70px;
                max-height: 70px;
                padding: 10px 15px;
            ]],
        },

        -- ── DIVIDER ──
        ui:Label{
            Text = "",
            StyleSheet = "background:#1A1A2E; min-height:1px; max-height:1px;",
        },

        -- ── BUTTONS ──
        ui:HGroup{
            StyleSheet = "background:#0E0E1C; padding: 7px 12px;",
            Spacing    = 8,
            ui:Button{
                ID   = "BtnClear",
                Text = "Clear",
                StyleSheet = [[
                    background:#1C1C2E; color:#556677;
                    border:1px solid #252535;
                    padding: 4px 12px; border-radius:3px; font-size:10px;
                ]],
            },
            ui:HGap(0, 1),
            ui:Button{
                ID   = "BtnConnect",
                Text = "▶  Connect Now",
                StyleSheet = [[
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 #FFD166, stop:1 #F4A261);
                    color:#111120; font-weight:700; letter-spacing:1px;
                    border:none; padding: 5px 20px;
                    border-radius:3px; font-size:11px;
                ]],
            },
        },
    },
})

local function extract_name_and_num(name)
    local prefix, num = string.match(name, "^(.-)(%d+)$")
    if prefix and num then
        return prefix, tonumber(num)
    else
        return name, 0
    end
end

local function sort_by_name(a, b)
    local prefA, numA = extract_name_and_num(a.Name)
    local prefB, numB = extract_name_and_num(b.Name)
    if prefA == prefB then
        return numA < numB
    end
    return prefA < prefB
end

local function sort_nodes_spatially(nodes_list, comp)
    local flow = comp and comp.CurrentFrame and comp.CurrentFrame.FlowView
    
    if #nodes_list < 2 then 
        return 
    end
    
    local positions = {}
    local minX, maxX = math.huge, -math.huge
    local minY, maxY = math.huge, -math.huge
    
    for _, node in ipairs(nodes_list) do
        local x, y
        if flow then
            x, y = flow:GetPos(node)
            if type(x) == "table" then
                y = x[2] or x.y or x.Y or 0
                x = x[1] or x.x or x.X or 0
            end
        end
        x = tonumber(x)
        y = tonumber(y)
        
        if not x or not y then
            -- Fallback to name sort if we can't get spatial data
            table.sort(nodes_list, sort_by_name)
            return
        end
        
        positions[node] = {x = x, y = y}
        minX = math.min(minX, x)
        maxX = math.max(maxX, x)
        minY = math.min(minY, y)
        maxY = math.max(maxY, y)
    end
    
    local rangeX = maxX - minX
    local rangeY = maxY - minY
    
    if rangeY > rangeX then
        -- Arranged vertically, sort by Y then X
        table.sort(nodes_list, function(a, b)
            local posA = positions[a]
            local posB = positions[b]
            if math.abs(posA.y - posB.y) > 0.5 then
                return posA.y > posB.y
            end
            return posA.x < posB.x
        end)
    else
        -- Arranged horizontally, sort by X then Y
        table.sort(nodes_list, function(a, b)
            local posA = positions[a]
            local posB = positions[b]
            if math.abs(posA.x - posB.x) > 0.5 then
                return posA.x < posB.x
            end
            return posA.y > posB.y
        end)
    end
end

local function log_msg(msg)
    local cur = win:GetItems().Log.Text or ""
    win:GetItems().Log.Text = cur .. msg .. "\n"
end

local function connect_nodes(src, dest)
    local out = src.Output
    if not out then
        local outs = src:GetOutputList()
        for _, o in pairs(outs) do
            out = o
            break
        end
    end
    if not out then return false end

    local ins = dest:GetInputList()
    local unconnected = {}
    for _, v in pairs(ins) do
        if v:GetConnectedOutput() == nil then
            table.insert(unconnected, v)
        end
    end
    
    table.sort(unconnected, function(a, b)
        local idA = a:GetID()
        local idB = b:GetID()
        
        local function getScore(id)
            if id == "Background" then return 1 end
            if id == "Foreground" then return 2 end
            local layerNum = string.match(id, "^Layer(%d+)$")
            if layerNum then return 10 + tonumber(layerNum) end
            local inputNum = string.match(id, "^Input(%d+)$")
            if inputNum then return 100 + tonumber(inputNum) end
            
            if string.find(id, "MaterialInput") then return 3 end
            if string.find(id, "SceneInput") then return 4 end
            if string.find(id, "EffectMask") then return 999 end
            return 500
        end
        
        local scoreA = getScore(idA)
        local scoreB = getScore(idB)
        if scoreA ~= scoreB then return scoreA < scoreB end
        return idA < idB
    end)
    
    for _, v in ipairs(unconnected) do
        v:ConnectTo(out)
        if v:GetConnectedOutput() ~= nil then
            return true
        end
    end
    return false
end

function win.On.AutoConnectWin.Close(ev)
    disp:ExitLoop()
end

function win.On.BtnClear.Clicked(ev)
    win:GetItems().Log.Text = ""
end

function win.On.BtnTargetToggle.Clicked(ev)
    if TARGET_MODE == "MediaOut" then
        TARGET_MODE = "MultiMerge"
        win:GetItems().BtnTargetToggle.Text = "✔  Target: MultiMerge"
        win:GetItems().BtnTargetToggle.StyleSheet = ON_STYLE
    else
        TARGET_MODE = "MediaOut"
        win:GetItems().BtnTargetToggle.Text = "—  Target: MediaOut"
        win:GetItems().BtnTargetToggle.StyleSheet = OFF_STYLE
    end
end

function win.On.BtnConnect.Clicked(ev)
    local comp = fusion.CurrentComp
    if not comp then
        log_msg("❌ No active composition.")
        return
    end

    local selectedNodes = comp:GetToolList(true)
    if not selectedNodes then
        log_msg("⚠️ No nodes selected.")
        return
    end

    local numNodes = 0
    for k, v in pairs(selectedNodes) do
        numNodes = numNodes + 1
    end

    if numNodes < 2 then
        log_msg("⚠️ Select at least 2 nodes.")
        return
    end

    local groups = {}
    local typeNames = {}

    for _, node in pairs(selectedNodes) do
        local nodeType = node.ID
        if not groups[nodeType] then
            groups[nodeType] = {}
            table.insert(typeNames, nodeType)
        end
        table.insert(groups[nodeType], node)
    end

    for _, typeName in ipairs(typeNames) do
        sort_nodes_spatially(groups[typeName], comp)
    end

    comp:Lock()

    local destGroup = nil
    local srcGroup = nil
    local successCount = 0

    if #typeNames == 2 then
        local g1 = groups[typeNames[1]]
        local g2 = groups[typeNames[2]]
        
        if #g1 == #g2 then
            -- Pairwise but could also be 1-to-1 Singletons (e.g. MediaOut and MultiMerge)
            if #g1 == 1 then
                local n1, n2 = g1[1], g2[1]
                if n1.ID == TARGET_MODE then
                    destGroup = g1; srcGroup = g2
                elseif n2.ID == TARGET_MODE then
                    destGroup = g2; srcGroup = g1
                end
            end
            
            if destGroup == nil then
                -- Normal Pairwise connection
                local success = connect_nodes(g1[1], g2[1])
                if success then
                    successCount = successCount + 1
                    log_msg(string.format("✅ Connected: %s -> %s", g1[1].Name, g2[1].Name))
                    for i = 2, #g1 do
                        if connect_nodes(g1[i], g2[i]) then
                            successCount = successCount + 1
                            log_msg(string.format("✅ Connected: %s -> %s", g1[i].Name, g2[i].Name))
                        else
                            log_msg(string.format("❌ Failed: %s -> %s", g1[i].Name, g2[i].Name))
                        end
                    end
                    log_msg("✅ Pairwise connection complete. (" .. successCount .. " pairs)")
                    comp:Unlock()
                    return
                else
                    success = connect_nodes(g2[1], g1[1])
                    if success then
                        successCount = successCount + 1
                        log_msg(string.format("✅ Connected: %s -> %s", g2[1].Name, g1[1].Name))
                        for i = 2, #g2 do
                            if connect_nodes(g2[i], g1[i]) then
                                successCount = successCount + 1
                                log_msg(string.format("✅ Connected: %s -> %s", g2[i].Name, g1[i].Name))
                            else
                                log_msg(string.format("❌ Failed: %s -> %s", g2[i].Name, g1[i].Name))
                            end
                        end
                        log_msg("✅ Pairwise connection complete. (" .. successCount .. " pairs)")
                        comp:Unlock()
                        return
                    else
                        log_msg("❌ Error: Incompatible nodes. Cannot connect " .. g1[1].Name .. " and " .. g2[1].Name .. ".")
                        comp:Unlock()
                        return
                    end
                end
            end
        else
            if #g1 == 1 then
                destGroup = g1
                srcGroup = g2
            elseif #g2 == 1 then
                destGroup = g2
                srcGroup = g1
            end
        end
    else
        -- More than 2 types. Attempt to find a single destination node based on TARGET_MODE if possible
        local singletons = {}
        local multis = {}
        for _, typeName in ipairs(typeNames) do
            if #groups[typeName] == 1 then
                table.insert(singletons, groups[typeName][1])
            else
                for _, node in ipairs(groups[typeName]) do
                    table.insert(multis, node)
                end
            end
        end
        
        -- If we have multiple singletons, pick the one that matches TARGET_MODE
        if #singletons == 1 then
            destGroup = singletons
            srcGroup = multis
        elseif #singletons > 1 then
            for _, node in ipairs(singletons) do
                if node.ID == TARGET_MODE then
                    destGroup = {node}
                else
                    table.insert(multis, node)
                end
            end
            if destGroup then
                srcGroup = multis
            end
        end
    end

    if destGroup and srcGroup and #destGroup == 1 then
        local dest = destGroup[1]
        sort_nodes_spatially(srcGroup, comp)
        
        for i = 1, #srcGroup do
            local success = connect_nodes(srcGroup[i], dest)
            if not success then
                success = connect_nodes(dest, srcGroup[i])
                if success then
                    log_msg(string.format("✅ Connected: %s -> %s", dest.Name, srcGroup[i].Name))
                    successCount = successCount + 1
                else
                    log_msg(string.format("❌ Failed: %s and %s are incompatible", srcGroup[i].Name, dest.Name))
                end
            else
                log_msg(string.format("✅ Connected: %s -> %s", srcGroup[i].Name, dest.Name))
                successCount = successCount + 1
            end
        end
        
        if successCount > 0 then
            log_msg("✅ Connected to destination node. (" .. successCount .. " links)")
        else
            log_msg("❌ Error: Could not connect any nodes. Types are incompatible.")
        end
    else
        log_msg("❌ Error: Could not determine pattern.\nPlease select equal amounts of 2 node types,\nOR multiple sources and exactly 1 destination node.")
    end

    comp:Unlock()
end

win:Show()
win:Resize(WIN_W, WIN_H)
disp:RunLoop()
win:Hide()
