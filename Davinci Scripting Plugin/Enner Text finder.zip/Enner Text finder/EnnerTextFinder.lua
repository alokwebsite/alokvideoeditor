-- ============================================================
--  ENNER TEXT FINDER  |  Alok Video Editor
--  Finds Text/TextPlus nodes containing specific text
-- ============================================================

local ui    = fu.UIManager
local disp  = bmd.UIDispatcher(ui)
local currentComp = fu:GetCurrentComp() or fusion.CurrentComp or comp

if not currentComp then
    print("No composition found!")
    return
end

-- ─── HELPERS ───────────────────────────────────────────────
local function log(textEdit, msg)
    local cur = textEdit.Text or ""
    textEdit.Text = cur .. msg .. "\n"
end

-- ─── TOGGLE STATE ────────────────────────────────────────────
local toggles = { matchCase = false }

local ON_STYLE = [[
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #0D3322, stop:1 #0F4428);
    color:#40E090; font-weight:700; font-size:11px;
    border:1px solid #1E7A45; border-radius:3px; padding:4px 14px;
]]
local OFF_STYLE = [[
    background:#131320; color:#2E3E4E; font-size:11px;
    border:1px solid #1C1C2C; border-radius:3px; padding:4px 14px;
]]

local function togText(label, on)
    return on and ("✔  " .. label) or ("—  " .. label)
end

-- ─── UI LAYOUT ─────────────────────────────────────────────
local WIN_W, WIN_H = 450, 340

local win = disp:AddWindow({
    ID          = "ETF",
    WindowTitle = "Enner Text Finder",
    Geometry    = { 400, 250, WIN_W, WIN_H },
    Spacing     = 0,

    ui:VGroup{
        Spacing = 0,

        -- ── HEADER ──
        ui:HGroup{
            Weight = 0,
            StyleSheet = "background:#12121E; padding: 9px 12px 7px 12px;",
            ui:Label{
                Text = "ENNER TEXT FINDER",
                StyleSheet = [[
                    font-family: 'Segoe UI', Arial, sans-serif;
                    font-size: 12px; font-weight: 700;
                    letter-spacing: 3px; color: #FFD166;
                ]],
            },
            ui:HGap(0, 1),
            ui:Button{
                ID = "BtnYoutube",
                Text = "Alok Video Editor",
                Alignment = { AlignRight = true },
                StyleSheet = [[
                    QPushButton {
                        background:#1C1C2E; color:#FFD166;
                        border:1px solid #252535;
                        padding: 4px 12px; border-radius:3px;
                        font-family: 'Segoe UI', Arial, sans-serif;
                        font-size: 10px; font-weight: 700;
                    }
                    QPushButton:hover {
                        background:#2C2C45; 
                        color:#FFFFFF;
                        border:1px solid #454565;
                    }
                    QPushButton:pressed {
                        background:#12121E;
                        color:#D5A940;
                    }
                ]],
            },
        },
        ui:Label{
            Weight = 0,
            Text = "",
            StyleSheet = "background:#FFD166; min-height:2px; max-height:2px;",
        },

        -- ── SEARCH BOX ──
        ui:HGroup{
            Weight = 0,
            StyleSheet = "background:#161626; padding: 12px 12px 6px 12px;",
            ui:LineEdit{
                ID = "SearchBox",
                PlaceholderText = "Enter text to find...",
                StyleSheet = [[
                    background: #0A0A14; color: #FFFFFF; font-size: 12px;
                    border: 1px solid #252535; border-radius: 3px; padding: 6px;
                ]],
            }
        },

        -- ── TOGGLE OPTIONS ──
        ui:HGroup{
            Weight = 0,
            StyleSheet = "background:#161626; padding: 6px 12px 12px 12px;",
            ui:Button{
                ID   = "BtnMatchCase",
                Text = "—  Match Case",
                StyleSheet = OFF_STYLE,
            },
            ui:HGap(0, 1),
        },

        -- ── DIVIDER ──
        ui:Label{
            Weight = 0,
            Text = "",
            StyleSheet = "background:#1A1A2E; min-height:1px; max-height:1px;",
        },

        -- ── LOG (scrollable) ──
        ui:TextEdit{
            Weight = 1,
            ID       = "Log",
            ReadOnly = true,
            StyleSheet = [[
                background:#0A0A14;
                color:#55EEBB;
                font-family: Consolas, monospace;
                font-size: 11px;
                border: none;
                padding: 8px 12px;
            ]],
        },

        -- ── DIVIDER ──
        ui:Label{
            Weight = 0,
            Text = "",
            StyleSheet = "background:#1A1A2E; min-height:1px; max-height:1px;",
        },

        -- ── BUTTONS ──
        ui:HGroup{
            Weight = 0,
            StyleSheet = "background:#0E0E1C; padding: 7px 12px;",
            Spacing    = 8,
            ui:Button{
                ID   = "BtnClear",
                Text = "Clear",
                StyleSheet = [[
                    background:#1C1C2E; color:#556677;
                    border:1px solid #252535;
                    padding: 4px 12px; border-radius:3px; font-size:10px;
                ]],
            },
            ui:HGap(0, 1),
            ui:Button{
                ID   = "BtnSearch",
                Text = "▶  Search Now",
                StyleSheet = [[
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 #FFD166, stop:1 #F4A261);
                    color:#111120; font-weight:700; letter-spacing:1px;
                    border:none; padding: 5px 20px;
                    border-radius:3px; font-size:11px;
                ]],
            },
        },
    },
})

-- ─── EVENTS ────────────────────────────────────────────────
local itm = win:GetItems()

win.On.BtnYoutube.Clicked = function()
    os.execute('start "" "https://www.youtube.com/@alokvideoeditornp"')
end

win.On.BtnMatchCase.Clicked = function()
    toggles.matchCase = not toggles.matchCase
    itm.BtnMatchCase.Text = togText("Match Case", toggles.matchCase)
    itm.BtnMatchCase.StyleSheet = toggles.matchCase and ON_STYLE or OFF_STYLE
end

win.On.BtnClear.Clicked = function()
    itm.Log.Text = ""
end

win.On.BtnSearch.Clicked = function()
    local searchTerm = itm.SearchBox.Text
    if not searchTerm or searchTerm == "" then
        log(itm.Log, "⚠️ Please enter text to search.")
        return
    end

    itm.Log.Text = ""
    log(itm.Log, "🔍 Searching for: '" .. searchTerm .. "' ...")
    
    local tools = currentComp:GetToolList(false)
    local foundNodes = {}
    local matchCase = toggles.matchCase

    for _, tool in pairs(tools) do
        -- Match Text, TextPlus, Text3D, MultiText, etc.
        if string.find(tool.ID, "Text") then
            local foundInThisTool = false
            
            -- MultiText nodes have multiple text inputs.
            -- Iterate through all inputs to find any that hold Text data.
            local inputs = tool:GetInputList()
            if inputs then
                for _, input in pairs(inputs) do
                    local attrs = input:GetAttrs()
                    if attrs and attrs.INPS_DataType == "Text" then
                        local id = input.ID
                        -- Only search actual content fields, ignore Font names, Styles, or internal metadata
                        if id == "StyledText" or id == "Text" or string.match(id, "^Text%d+$") or string.match(id, "^StyledText%d+$") then
                            local textInput = tool[id]
                            if textInput then
                                local val = textInput[currentComp.CurrentTime]
                                if val and type(val) == "string" then
                                    local searchIn = val
                                    local searchFor = searchTerm
                                    
                                    if not matchCase then
                                        searchIn = string.lower(searchIn)
                                        searchFor = string.lower(searchFor)
                                    end
                                    
                                    if string.find(searchIn, searchFor, 1, true) then
                                        foundInThisTool = true
                                        break -- Found a match, no need to check other inputs on this node
                                    end
                                end
                            end
                        end
                    end
                end
            end
            
            if foundInThisTool then
                table.insert(foundNodes, tool)
            end
        end
    end

    if #foundNodes > 0 then
        local flow = currentComp.CurrentFrame and currentComp.CurrentFrame.FlowView
        if flow then flow:Select() end
        
        log(itm.Log, "✅ Found in " .. #foundNodes .. " node(s):")
        for _, t in ipairs(foundNodes) do
            log(itm.Log, "   - " .. t.Name)
            if flow then flow:Select(t, true) end
        end
        
        currentComp:SetActiveTool(foundNodes[1])
        log(itm.Log, "👉 Selected all matches. Active node: " .. foundNodes[1].Name)
    else
        log(itm.Log, "❌ No nodes found containing: '" .. searchTerm .. "'")
    end
end

win.On.ETF.Close = function() disp:ExitLoop() end

-- ─── LAUNCH ────────────────────────────────────────────────
win:Show()
win:Resize(WIN_W, WIN_H)
disp:RunLoop()
win:Hide()
