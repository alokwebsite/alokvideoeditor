# DaVinci Resolve Copy-Pasta Plugin V2

> A lightning-fast copy-paste workflow for DaVinci Resolve (Studio version required for scripting API).

## Features

1. **Copy Frame to Clipboard**: Instantly grab the current frame under your playhead and copy it to your system clipboard. Paste it anywhere!
2. **Paste Image to Timeline**: Copy any image from the internet or your PC, and paste it directly into your DaVinci Resolve timeline.
3. **Copy Paste UI**: A sleek standalone interface allowing you to trigger actions via buttons and manage settings.

---

> [!IMPORTANT]
> Your folder must be named **`Copy Pasta V2`** and placed directly inside the `Utility` folder (i.e., `Utility/Copy Pasta V2`). If the folder is named something else, the plugin will break!

## 🪟 Windows Installation

This new version is written in native Lua and requires **NO Python installation**!

### Step 1: Copy Scripts to Resolve
1. Open DaVinci Resolve.
2. Go to the top menu: `Workspace` -> `Scripts` -> `Open Scripts Folder`.
3. Open the `Utility` folder inside the scripts directory that appears.
4. Copy this entire folder (ensure it is named exactly **`Copy Pasta V2`**) into that `Utility` folder.

---

## Assign Keyboard Shortcuts

1. Restart DaVinci Resolve or go to `Workspace` -> `Scripts` -> `Update Scripts`.
2. Open `DaVinci Resolve` -> `Keyboard Customization` (or press `Ctrl+Alt+K`).
3. In the search bar on the right, type "Copy Paste UI". Look under `Workspace` -> `Scripts` -> `Utility`.
4. Assign your preferred shortcut to open the UI.

## Where are my pasted images saved?
When you paste an image into Resolve, it is permanently saved in the folder you specify in the UI settings so DaVinci Resolve can link to it. By default, this is:

`C:\Users\<YourUsername>\Documents\Davinci Resolve Copy Pasta_2\`
