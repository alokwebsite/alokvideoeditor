# Copy Pasta V2 (macOS Version)

A powerful clipboard manager and image pasting utility designed natively for DaVinci Resolve on macOS. 

This script allows you to copy frames directly from your timeline to your Mac's clipboard, or instantly paste images from your browser/Finder directly into your timeline without dealing with importing media manually.

## Features
1. **Copy Frame to Clipboard:** Instantly grab the current frame under your playhead and copy it to your macOS clipboard as an image. You can then paste it anywhere (Slack, Discord, Apple Messages, Photoshop, etc.).
2. **Paste Image to Timeline:** Found an image on Safari or copied a file in Finder? Just click "Paste Image" and the script will automatically download the image, organize it into your project folders, and place it directly onto your DaVinci Resolve timeline!
3. **Save UI Presets:** Configure your favorite colors, folder paths, and settings and save them as presets to instantly switch between project setups.
4. **Auto-Sanitization:** If you share your presets with other Mac users, the plugin automatically detects and rewrites hardcoded username paths (e.g. `/Users/FriendName/`) so your friends never experience permission errors.

## Installation for Mac

> [!IMPORTANT]
> Your folder must be named **`Copy Pasta V2`** and placed directly inside the DaVinci Resolve `Utility` script folder. If it is named differently, the plugin will fail to find its configuration files!

1. Open **Finder**.
2. From the top menu bar, click **Go** -> **Go to Folder...** (or press `Cmd + Shift + G`).
3. Paste the following path and hit Enter:
   `/Library/Application Support/Blackmagic Design/DaVinci Resolve/Support/Fusion/Scripts/Utility/`
4. Copy the entire `Copy Pasta V2` folder into this `Utility` folder.
5. Restart DaVinci Resolve.

## Usage
1. Open DaVinci Resolve.
2. Go to the top menu bar: **Workspace** -> **Scripts** -> **Utility** -> **Copy Pasta V2** -> **Copy Paste UI Mac**.
3. **To Paste:** Copy any image (Right-click -> Copy Image) and click **Paste Image to Timeline**.
4. **To Copy:** Move your playhead to any frame and click **Copy Frame to Clipboard**.

## Technical Details (Mac)
- **Dependencies:** This script runs native `osascript` (AppleScript) in the background to interface with the macOS Pasteboard (NSPasteboard). 
- **Storage:** All pasted images and copied frames are neatly organized and saved inside your `~/Documents/Davinci Resolve Copy Pasta V2/` directory so your media never goes offline.

*Created with ❤️ for Mac Video Editors.*
