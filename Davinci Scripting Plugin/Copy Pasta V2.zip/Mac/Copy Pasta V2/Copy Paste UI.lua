-- Copy Paste UI.lua
local resolve = Resolve()
local fusion = resolve:Fusion()
local ui = fusion.UIManager
local dispatcher = bmd.UIDispatcher(ui)

local home = os.getenv("HOME")
local baseDir = home .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Support/Fusion/Scripts/Utility/"

_G.COPY_PASTA_BASE_DIR = baseDir .. "Copy Pasta V2"

-- Load stored paths and colors

local scriptDir = _G.COPY_PASTA_BASE_DIR .. "/"

local configPath = scriptDir .. "config.lua"
local defaultPath = home .. "/Documents/Davinci Resolve Copy Pasta V2"

local function verifyDir(path)
    os.execute('mkdir -p "' .. path .. '" 2>/dev/null')
    local test_file = path .. "/test_write.tmp"
    local f = io.open(test_file, "w")
    if f then
        f:close()
        os.execute('rm -f "' .. test_file .. '" 2>/dev/null')
        return true
    end
    return false
end

local presetDir = scriptDir .. "Presets/"
local safePresetDir = presetDir:sub(1, -2)
os.execute('mkdir -p "' .. safePresetDir .. '" 2>/dev/null')

local defaultColor = "Blue"

local function LoadConfig()
    local f = io.open(configPath, "r")
    local cPath = defaultPath
    local cColor = defaultColor
    local cPreset = "--- Custom ---"
    if f then
        local content = f:read("*a")
        f:close()
        local path = content:match('saveDir%s*=%s*%[%[(.-)%]%]') or content:match('return%s+"(.-)"')
        if path and verifyDir(path) then cPath = path end
        local color = content:match('pasteColor%s*=%s*["\'](.-)["\']')
        if color then cColor = color end
        local preset = content:match('lastPreset%s*=%s*["\'](.-)["\']')
        if preset then cPreset = preset end
    else
        local fw = io.open(configPath, "w")
        if fw then
            fw:write('return {\\n  saveDir = [[' .. cPath .. ']],\\n  pasteColor = "' .. cColor .. '",\\n  lastPreset = "' .. cPreset .. '"\\n}')
            fw:close()
        end
    end
    return cPath, cColor, cPreset
end

local function SaveConfig(path, color, presetName)
    local f = io.open(configPath, "w")
    if f then
        f:write('return {\n  saveDir = [[' .. path .. ']],\n  pasteColor = "' .. color .. '",\n  lastPreset = "' .. presetName .. '"\n}')
        f:close()
    end
end

local function SavePreset(name, path, color)
    local safePresetDir = presetDir:sub(1, -2)
    os.execute('mkdir -p "' .. safePresetDir .. '" 2>/dev/null')
    local filePath = presetDir .. name .. ".lua"
    local f, err = io.open(filePath, "w")
    if f then
        f:write('return {\\n  saveDir = [[' .. path .. ']],\\n  pasteColor = "' .. color .. '"\\n}')
        f:close()
        return true
    else
        if ui_log then ui_log("❌ Failed to save preset: " .. tostring(err)) end
        return false
    end
end

local function LoadPreset(name)
    local f = io.open(presetDir .. name .. ".lua", "r")
    if f then
        local content = f:read("*a")
        f:close()
        local path = content:match('saveDir%s*=%s*%[%[(.-)%]%]')
        local color = content:match('pasteColor%s*=%s*["\'](.-)["\']')
        return path, color
    end
    return nil, nil
end

local function GetPresetList()
    local presets = {}
    local handle = io.popen('ls -1 "' .. presetDir .. '"*.lua 2>/dev/null')
    if handle then
        for line in handle:lines() do
            local name = line:match("([^/]+)%.lua$")
            if name then table.insert(presets, name) end
        end
        handle:close()
    end
    return presets
end

local loadedPath, loadedColor, loadedPreset = LoadConfig()
local WIN_W, WIN_H = 600, 550

-- Create the window
local window = dispatcher:AddWindow({
    ID          = "CopyPastaUIAA",
    WindowTitle = "Copy Pasta V2",
    Geometry    = { 400, 250, 600, 550 },
    Spacing     = 0,

    ui:VGroup{
        StyleSheet = "background:#161626;",
        Spacing = 0,
        
        -- ── HEADER (THE WATERMARK LIKE BEFORE) ──
        ui:HGroup{
            Weight = 0,
            StyleSheet = "background:#161626; padding: 9px 12px 7px 12px;",
            ui:Label{
                Text = "COPY PASTA V2",
                Weight = 0,
                StyleSheet = [[
                    font-family: 'Segoe UI', Arial, sans-serif;
                    font-size: 12px; font-weight: 700;
                    letter-spacing: 3px; color: #FFD166;
                    background: #1A1A2E;
                    padding: 4px 12px;
                    border-radius: 4px;
                ]],
            },
            ui:HGap(0, 1),
            ui:Button{
                ID = "BtnYouTube",
                Text = "ALOK VIDEO EDITOR",
                Weight = 0,
                StyleSheet = [[
                    QPushButton { background: transparent; border: none; padding: 0px; font-family: 'Segoe UI', Arial, sans-serif; font-size: 12px; font-weight: 700; letter-spacing: 3px; color: #FFD166; }
                    QPushButton:hover { color: #FFFFFF; }
                ]],
            },
        },
        ui:Label{
            Text = "",
            Weight = 0,
            StyleSheet = "background:#FFD166; min-height:2px; max-height:2px;",
        },

        -- ── SIDE-BY-SIDE CONTENT ──
        ui:HGroup{
            Spacing = 0,
            Weight = 1,

            -- ── LEFT COLUMN: MAIN WORKFLOW ──
            ui:VGroup{
                MinimumSize = { 320, 0 },
                MaximumSize = { 320, 99999 },
                Weight = 0,
                StyleSheet = "background:#161626; padding: 25px;",
                Spacing = 20,
                
                -- Main Buttons
                ui:Button{
                    ID   = "BtnCopy",
                    Text = "📷  Copy Frame to Clipboard",
                    Weight = 0,
                    MinimumSize = { 0, 50 },
                    StyleSheet = [[
                        QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #2A2A3C, stop:1 #35354D); color:#E0E0E0; font-weight:700; letter-spacing:1px; border:1px solid #40405A; border-radius:6px; font-size:14px; }
                        QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #35354D, stop:1 #4A4A6A); border:1px solid #555577; color:#FFFFFF; }
                    ]],
                },
                ui:Button{
                    ID   = "BtnPaste",
                    Text = "📥  Paste Image to Timeline",
                    Weight = 0,
                    MinimumSize = { 0, 50 },
                    StyleSheet = [[
                        QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #FFD166, stop:1 #F4A261); color:#111120; font-weight:700; letter-spacing:1px; border:none; border-radius:6px; font-size:14px; }
                        QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #FFE088, stop:1 #F6B880); }
                    ]],
                },
                
                -- Preview Area
                ui:VGroup{
                    Weight = 1,
                    StyleSheet = "background:#0A0A14; border: 1px dashed #2A2A3C; border-radius: 6px;",
                    ui:Label{
                        ID = "PreviewLabel",
                        Weight = 1,
                        Text = "No Frame Copied Yet",
                        Alignment = { AlignHCenter = true, AlignVCenter = true },
                        StyleSheet = "color:#445566; font-size:11px; border: none; background: transparent;",
                    },
                },
            },
            
            -- ── DIVIDER ──
            ui:Label{
                Text = "",
                Weight = 0,
                MinimumSize = { 1, 0 },
                MaximumSize = { 1, 99999 },
                StyleSheet = "background:#2A2A3C;",
            },

            -- ── RIGHT COLUMN: SETTINGS ──
            ui:VGroup{
                ID = "RightSettingsPanel",
                MinimumSize = { 270, 0 },
                Weight = 1.2,
                StyleSheet = "background:#1A1A2E;",
                Spacing = 0,
                
                -- Settings Header
                ui:HGroup{
                    StyleSheet = "background:#1A1A2E; padding: 15px 20px 5px 20px;",
                    Weight = 0,
                    ui:Label{
                        Text = "SETTINGS & PREFERENCES",
                        Weight = 1,
                        StyleSheet = "color:#8899AA; font-size:11px; font-weight:bold; letter-spacing:1.5px; background: transparent;",
                    },
                },
                
                -- Settings Body
                ui:VGroup{
                    StyleSheet = "padding: 10px 20px; background: transparent;",
                    Spacing = 15,
                    Weight = 0,
                    
                    -- Export Path
                    ui:VGroup{
                        Spacing = 5,
                        Weight = 0,
                        ui:Label{
                            Text = "FILE EXPORT PATH",
                            Weight = 0,
                            StyleSheet = "color:#667788; font-size:10px; font-weight:bold; letter-spacing:1px; background: transparent;",
                        },
                        ui:HGroup{
                            Spacing = 5,
                            Weight = 0,
                            ui:LineEdit{
                                ID = "SavePathEdit",
                                Text = loadedPath,
                                ReadOnly = true,
                                StyleSheet = "background:#0A0A14; color:#AABBCC; border:1px solid #2A2A3C; padding:6px; border-radius: 4px;",
                            },
                            ui:Button{
                                ID = "BtnBrowse",
                                Text = "Browse...",
                                StyleSheet = "QPushButton { background:#2A2A3C; color:#E0E0E0; border:1px solid #40405A; padding:6px 12px; border-radius: 4px; } QPushButton:hover { background:#40405A; color:#FFFFFF; }",
                            },
                            ui:Button{
                                ID = "BtnOpenFolder",
                                Text = "Open",
                                ToolTip = "Open in Explorer",
                                StyleSheet = "QPushButton { background:#2A2A3C; color:#55EEBB; border:1px solid #40405A; padding:6px 12px; border-radius: 4px; } QPushButton:hover { background:#40405A; color:#FFFFFF; }",
                            },
                        },
                        ui:CheckBox{
                            ID = "ChkAutoExplore",
                            Text = "Auto-Save Copied Frame to Export Folder",
                            Checked = false,
                            StyleSheet = "color:#AABBCC; font-size:11px; padding-top: 5px; background: transparent;",
                        },
                    },
                    
                    -- Presets & Colors
                    ui:VGroup{
                        Spacing = 5,
                        Weight = 0,
                        ui:Label{
                            Text = "PRESETS & COLORS",
                            Weight = 0,
                            StyleSheet = "color:#667788; font-size:10px; font-weight:bold; letter-spacing:1px; background: transparent;",
                        },
                        ui:HGroup{
                            Spacing = 8,
                            Weight = 0,
                            ui:Label{
                                Text = "CLIP COLOR:",
                                Weight = 0,
                                StyleSheet = "color:#8899AA; font-size:10px; font-weight: bold; background: transparent;",
                            },
                            ui:Label{
                                ID = "ColorPreview",
                                Text = "    ",
                                StyleSheet = "background: transparent; border: 1px dashed #556677; border-radius: 6px; min-width: 16px; min-height: 16px; max-width: 16px; max-height: 16px; margin-top: 1px;",
                            },
                            ui:ComboBox{
                                ID = "ColorCombo",
                                Weight = 1,
                                StyleSheet = "background:#0A0A14; color:#E0E0E0; border:1px solid #2A2A3C; padding:5px; border-radius: 4px;",
                            },
                        },
                        ui:HGroup{
                            Spacing = 8,
                            Weight = 0,
                            ui:ComboBox{
                                ID = "PresetCombo",
                                Weight = 1,
                                StyleSheet = "background:#0A0A14; color:#E0E0E0; border:1px solid #2A2A3C; padding:5px; border-radius: 4px;",
                            },
                            ui:Button{
                                ID = "BtnShowDelete",
                                Text = "🗑️",
                                Weight = 0,
                                StyleSheet = "QPushButton { background:#2A2A3C; color:#F4A261; border:1px solid #40405A; border-radius:4px; padding: 5px; min-width:28px; max-width:28px; } QPushButton:hover { background:#40405A; }",
                            },
                            ui:Button{
                                ID = "BtnSavePreset",
                                Text = "💾  Save Preset",
                                Weight = 0,
                                StyleSheet = "QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #253A2A, stop:1 #35503D); color:#55EEBB; font-weight: bold; font-size:11px; border:1px solid #3A5A4A; border-radius:4px; padding: 5px 15px; } QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #35503D, stop:1 #45654D); border:1px solid #55EEBB; }",
                            },
                        },
                    },
                },
                
                -- Divider
                ui:Label{
                    Text = "",
                    Weight = 0,
                    MinimumSize = { 0, 1 },
                    MaximumSize = { 99999, 1 },
                    StyleSheet = "background:#25253A;",
                },
                
                -- Log Area
                ui:TextEdit{
                    ID       = "Log",
                    ReadOnly = true,
                    Weight   = 1,
                    StyleSheet = [[
                        background:#1A1A2E;
                        color:#55EEBB;
                        font-family: Consolas, monospace;
                        font-size: 11px;
                        border: none;
                        padding: 10px 20px;
                    ]],
                },
                
                -- Log Footer
                ui:HGroup{
                    Weight = 0,
                    MinimumSize = { 0, 40 },
                    MaximumSize = { 99999, 40 },
                    StyleSheet = "background:#161626; padding: 10px 20px;",
                    ui:Button{
                        ID   = "BtnClear",
                        Text = "Clear Log",
                        Weight = 0,
                        StyleSheet = [[
                            QPushButton { background:#1C1C2E; color:#667788; border:1px solid #2A2A3C; padding: 5px 15px; border-radius:4px; font-size:10px; }
                            QPushButton:hover { background:#2A2A3C; color:#AABBCC; border:1px solid #40405A; }
                        ]],
                    },
                    ui:HGap(0, 1),
                },
            },
        },
    },
})


local saveWin = dispatcher:AddWindow({
    ID = "SavePresetWin_v2",
    WindowTitle = "Name Your Preset",
    Geometry = { 450, 300, 300, 160 },
    Spacing = 10,
    ui:VGroup{
        StyleSheet = "background:#161626; padding: 15px;",
        ui:Label{
            Text = "Enter Preset Name:",
            StyleSheet = "color:#E0E0E0; font-size:11px; font-weight:bold;",
        },
        ui:LineEdit{
            ID = "PresetNameEdit",
            PlaceholderText = "e.g., Client Vlogs",
            StyleSheet = "background:#0A0A14; color:#FFF; border:1px solid #40405A; padding:5px;",
        },
        ui:VGap(10, 1),
        ui:HGroup{
            Weight = 0,
            ui:HGap(1, 1),
            ui:Button{
                ID = "BtnCancelSave",
                Text = "Cancel",
                StyleSheet = "QPushButton { background:#2A2A3C; color:#FFF; padding:5px 15px; border-radius:3px; } QPushButton:hover { background:#40405A; }",
            },
            ui:Button{
                ID = "BtnConfirmSave",
                Text = "Save",
                StyleSheet = "QPushButton { background:#35503D; color:#55EEBB; padding:5px 15px; border-radius:3px; font-weight:bold; } QPushButton:hover { background:#45654D; color:#FFFFFF; }",
            },
        }
    }
})

local itm = window:GetItems()
local saveItm = saveWin:GetItems()

local delWin = dispatcher:AddWindow({
    ID = "DeletePresetWin_v2",
    WindowTitle = "Delete Preset",
    Geometry = { 450, 300, 300, 160 },
    Spacing = 10,
    ui:VGroup{
        StyleSheet = "background:#161626; padding: 15px;",
        ui:Label{
            Text = "Select Preset to Delete:",
            StyleSheet = "color:#E0E0E0; font-size:11px; font-weight:bold;",
        },
        ui:ComboBox{
            ID = "DelPresetCombo",
            StyleSheet = "background:#0A0A14; color:#FFF; border:1px solid #40405A; padding:5px;",
        },
        ui:VGap(10, 1),
        ui:HGroup{
            Weight = 0,
            ui:HGap(1, 1),
            ui:Button{
                ID = "BtnCancelDel",
                Text = "Cancel",
                StyleSheet = "QPushButton { background:#2A2A3C; color:#FFF; padding:5px 15px; border-radius:3px; } QPushButton:hover { background:#40405A; }",
            },
            ui:Button{
                ID = "BtnConfirmDel",
                Text = "Delete",
                StyleSheet = "QPushButton { background:#502A2A; color:#FF5555; padding:5px 15px; border-radius:3px; font-weight:bold; } QPushButton:hover { background:#703A3A; color:#FFAAAA; }",
            },
        }
    }
})

local delItm = delWin:GetItems()

-- Populate colors
local colorData = {
    {"Default Color", "transparent"},
    {"Orange", "#EB7D34"},
    {"Apricot", "#F2A93B"},
    {"Yellow", "#E8D23A"},
    {"Lime", "#94C440"},
    {"Olive", "#6B7B36"},
    {"Green", "#4FA853"},
    {"Teal", "#33A1A6"},
    {"Navy", "#2A5675"},
    {"Blue", "#3878BF"},
    {"Purple", "#8A4F9E"},
    {"Violet", "#B35E99"},
    {"Pink", "#E8668E"},
    {"Tan", "#C7AB8F"},
    {"Beige", "#AB9175"},
    {"Brown", "#755130"},
    {"Chocolate", "#4D3220"}
}

local function UpdateColorPreview(colorName)
    local hex = "transparent"
    for _, c in ipairs(colorData) do
        if c[1] == colorName then hex = c[2]; break end
    end
    if hex == "transparent" then
        itm.ColorPreview.StyleSheet = "background: transparent; border: 1px dashed #556677; border-radius: 6px; min-width: 12px; min-height: 12px; max-width: 12px; max-height: 12px; margin-top: 1px;"
    else
        itm.ColorPreview.StyleSheet = "background: " .. hex .. "; border: 1px solid " .. hex .. "; border-radius: 6px; min-width: 12px; min-height: 12px; max-width: 12px; max-height: 12px; margin-top: 1px;"
    end
end

for _, c in ipairs(colorData) do
    itm.ColorCombo:AddItem(c[1])
end

-- Set the initial combo box to the loaded color
for i=0, #colorData-1 do
    if colorData[i+1][1] == loadedColor then
        itm.ColorCombo.CurrentIndex = i
        UpdateColorPreview(loadedColor)
        break
    end
end

local sessionLog = ""
local function ui_log(msg)
    local timeStr = os.date("%H:%M:%S")
    local logLine = "[" .. timeStr .. "] " .. msg
    if sessionLog == "" then
        sessionLog = logLine
    else
        sessionLog = logLine .. "\n" .. sessionLog
    end
    
    local logBox = window:GetItems().Log
    if logBox then
        logBox.Text = sessionLog
    end
end

local function ExecuteCopyFrame(auto_save_enabled)
    _G.DVR_COPYPASTA_SAVE_DIR = itm.SavePathEdit.Text
    _G.DVR_COPYPASTA_PASTE_COLOR = itm.ColorCombo.CurrentText
-- Copy Frame to Clipboard.lua
    local function ShowError(message)
        ui_log("❌ " .. message)
    end
    
    local resolve = Resolve()
    if not resolve then
        ShowError("Could not connect to DaVinci Resolve.")
        return nil
    end
    
    local projectManager = resolve:GetProjectManager()
    local project = projectManager:GetCurrentProject()
    if not project then
        ShowError("No active project found.")
        return nil
    end
    
    local timeline = project:GetCurrentTimeline()
    if not timeline then
        ShowError("No active timeline found. Please open a timeline.")
        return nil
    end
    
    local temp_dir = _G.COPY_PASTA_BASE_DIR .. "/dvr_copypasta_preview"
    os.execute('mkdir -p "' .. temp_dir .. '" 2>/dev/null')
    os.execute('rm -f "' .. temp_dir .. '"/*.png 2>/dev/null')
    os.execute('rm -f "' .. temp_dir .. '"/*.jpg 2>/dev/null')
    
    local res = false
    local jpg_path = ""
    
    local current_page = resolve:GetCurrentPage()
    if current_page == "fusion" then
        local comp = fusion:GetCurrentComp()
        if not comp then
            ShowError("Could not find active Fusion composition.")
            return nil
        end
        
        -- Require the user to explicitly select a tool to copy
        local tool = comp.ActiveTool
        if not tool then
            ShowError("Please select a node to copy.")
            return nil
        end
        
        -- We no longer use StartUndo/Undo because firing Undo immediately after Render() causes race conditions and crashes DaVinci Resolve.
        local saver = comp:AddTool("Saver", -32768, -32768)
        local base_clip = temp_dir .. "/frame.png"
        saver.Clip = base_clip
        saver.OutputFormat = "PNGFormat"
        saver:SetInput("SaveAlpha", 1)
        pcall(function() saver:SetInput("PNGFormat.SaveAlpha", 1) end)
        pcall(function() saver.SaveAlpha = 1 end)
        
        -- Connect to the active tool
        local out = tool:FindMainOutput(1)
        if out then
            saver:ConnectInput("Input", out)
        else
            ui_log("❌ Selected tool has no valid output.")
            saver:Delete()
            return nil
        end
        
        -- Save original Render I/O range
        local attrs = comp:GetAttrs()
        local old_start = attrs.COMPN_RenderStart
        local old_end = attrs.COMPN_RenderEnd
        
        -- Render the single frame
        local t = comp.CurrentTime
        comp:Render({Start = t, End = t, Wait = true, Tool = saver})
        
        -- Restore original Render I/O range
        if old_start and old_end then
            comp:SetAttrs({COMPN_RenderStart = old_start, COMPN_RenderEnd = old_end})
        end
        
        -- Gracefully delete the node directly instead of relying on the global Undo stack
        saver:Delete()
        
        -- Because Wait=true guarantees the render is finished, we don't need a heavy polling loop.
        -- We use a lightning-fast native CMD command to find the file
        local list_file = temp_dir .. "/list.txt"
        os.execute('ls "' .. temp_dir .. '"/*.png > "' .. list_file .. '" 2>/dev/null')
        
        local actual_file = ""
        local lf = io.open(list_file, "r")
        if lf then
            actual_file = lf:read("*l") or ""
            lf:close()
        end
        os.execute('rm -f "' .. list_file .. '" 2>/dev/null')
        
        if actual_file and actual_file ~= "" then
            jpg_path = actual_file
            res = true
        else
            ShowError("Fusion render failed or timed out.")
            return nil
        end
    else
        -- Standard Edit page timeline export
        local current_page = resolve:GetCurrentPage()
        local sys_tmp = os.getenv("TMPDIR")
        if not sys_tmp or sys_tmp == "" then sys_tmp = "/tmp" end
        -- Remove trailing slash if present
        sys_tmp = sys_tmp:gsub("/$", "")
        local safe_temp = sys_tmp .. "/dvr_copypasta_preview"
        os.execute('mkdir -p "' .. safe_temp .. '" 2>/dev/null')
        os.execute('rm -f "' .. safe_temp .. '/*.png" 2>/dev/null')
        os.execute('rm -f "' .. safe_temp .. '/*.jpg" 2>/dev/null')
        
        -- Try the silent API first (often works better with .png)
        local frame_path = safe_temp .. "/frame.png"
        local success, result = pcall(function() return timeline:ExportCurrentFrameAsStill(frame_path) end)
        if success then res = result else res = false end
        
        if res then
            local start_time = os.clock()
            local file_exists = false
            while os.clock() - start_time < 2.0 do
                local f = io.open(frame_path, "rb")
                if f then
                    local size = f:seek("end")
                    f:close()
                    if size and size > 0 then
                        file_exists = true
                        break
                    end
                end
            end
            if not file_exists then res = false end
        end
        
        -- Fallback to bulletproof GrabStill if silent API failed
        if not res then
            local gallery = project:GetGallery()
            local current_album = gallery and gallery:GetCurrentStillAlbum() or nil
            
            if current_album then
                local still = timeline:GrabStill()
                
                -- INSTANTLY jump back to original page so the user doesn't notice the Color page jump!
                if resolve:GetCurrentPage() ~= current_page then
                    resolve:OpenPage(current_page)
                end
                
                if still then
                    local prefix = "dvr_frame_"
                    local export_res = current_album:ExportStills({still}, safe_temp, prefix, "png")
                    if export_res then
                        local cmd = 'ls "' .. safe_temp .. '"/' .. prefix .. '*.png 2>/dev/null | head -n 1'
                        local handle = io.popen(cmd)
                        local filename = handle:read("*l")
                        if handle then handle:close() end
                        if filename and filename ~= "" then
                            frame_path = filename
                            res = true
                        end
                    end
                    current_album:DeleteStills({still})
                end
            end
        end
        
        jpg_path = frame_path
    end
    
    if res then
        local function verifyDir(path)
            os.execute('mkdir -p "' .. path .. '" 2>/dev/null')
            local test_file = path .. "/test_write.tmp"
            local f = io.open(test_file, "w")
            if f then f:close(); os.execute('rm -f "' .. test_file .. '" 2>/dev/null'); return true end
            return false
        end
    
        -- Resolve the save location from config
        local baseDir = _G.DVR_COPYPASTA_SAVE_DIR
        if not baseDir then
            local appdata = _G.COPY_PASTA_BASE_DIR
            local configPath = appdata .. "/config.lua"
            local f = io.open(configPath, "r")
            if f then
                local content = f:read("*a")
                f:close()
                local parsed_path = content:match('return%s+"(.-)"')
                if parsed_path and verifyDir(parsed_path) then
                    baseDir = parsed_path
                end
            end
        end
        if not baseDir or not verifyDir(baseDir) then
            baseDir = os.getenv("HOME") .. "/Documents/Davinci Resolve Copy Pasta V2"
            os.execute('mkdir -p "' .. baseDir .. '" 2>/dev/null')
        end

        local projectName = project:GetName() or "Unknown Project"
        local tlName = "No Timeline"
        if timeline then tlName = timeline:GetName() end
        local cPage = resolve:GetCurrentPage()
        local pNames = { media = "Media Page", cut = "Cut Page", edit = "Edit Page", fusion = "Fusion Page", color = "Color Page", fairlight = "Fairlight Page", deliver = "Deliver Page" }
        local pName = pNames[cPage] or "Unknown Page"
        
        local function cleanFilename(name) return name:gsub('[<>:"/\\\\|?*]', '_') end
        
        local save_dir = baseDir .. "/" .. cleanFilename(projectName) .. "/" .. cleanFilename(tlName) .. "/You copied"
        local ts = tostring(os.time())
        local ext = jpg_path:match("^.+(%..+)$") or ".jpg"
        
        local final_path = ""
        local safe_final_path = ""
        local ps_cmd = ""
        
        if auto_save_enabled then
            os.execute('mkdir -p "' .. save_dir .. '" 2>/dev/null')
            final_path = save_dir .. "/copied_frame_" .. ts .. "_img" .. ext
            os.execute('cp -f "' .. jpg_path .. '" "' .. final_path .. '" >/dev/null 2>&1')
            
            _G.LAST_COPIED_FRAME = final_path
            _G.LAST_COPIED_DIR = save_dir
        else
            -- Do not save permanently, just put image in memory clipboard!
            final_path = jpg_path
            _G.LAST_COPIED_FRAME = final_path
        end
        
        safe_final_path = final_path:gsub("'", "'\\''")
        if final_path:lower():match("%.png$") then
            -- Mac AppleScript to copy FileURL AND raw PNG Data (lossless transparency)
            ps_cmd = 'osascript -e \'use framework "AppKit"\' -e \'set filePath to "' .. safe_final_path .. '"\' -e \'set fileURL to current application\\\'s NSURL\\\'s fileURLWithPath:filePath\' -e \'set fileData to current application\\\'s NSData\\\'s dataWithContentsOfFile:filePath\' -e \'set pb to current application\\\'s NSPasteboard\\\'s generalPasteboard()\' -e \'pb\\\'s clearContents()\' -e \'pb\\\'s writeObjects:{fileURL}\' -e \'pb\\\'s setData:fileData forType:"public.png"\''
        else
            ps_cmd = 'osascript -e \'set the clipboard to (read (POSIX file "' .. safe_final_path .. '") as JPEG picture)\''
        end
        
        os.execute(ps_cmd)
        ui_log("✅ Successfully copied frame to clipboard!")
    else
        ShowError("Failed to export current frame as still. Ensure your playhead is over a video clip.")
    end
    

    
end

local function ExecutePasteImage()
    _G.DVR_COPYPASTA_SAVE_DIR = itm.SavePathEdit.Text
    _G.DVR_COPYPASTA_PASTE_COLOR = itm.ColorCombo.CurrentText
-- Paste Image to Timeline.lua
    local function ShowError(message)
        ui_log("❌ " .. message)
    end
    
    local resolve = Resolve()
    if not resolve then
        ShowError("Could not connect to DaVinci Resolve.")
        return nil
    end
    
    local projectManager = resolve:GetProjectManager()
    local project = projectManager:GetCurrentProject()
    if not project then
        ShowError("No active project found.")
        return nil
    end
    
    local mediaPool = project:GetMediaPool()
    local timeline = project:GetCurrentTimeline()
    
    -- 1. Setup permanent storage directory
    local defaultBaseDir = os.getenv("HOME") .. "/Documents/Davinci Resolve Copy Pasta V2"
    
    local function verifyDir(path)
        os.execute('mkdir -p "' .. path .. '" 2>/dev/null')
        local test_file = path .. "/test_write.tmp"
        local f = io.open(test_file, "w")
        if f then f:close(); os.execute('rm -f "' .. test_file .. '" 2>/dev/null'); return true end
        return false
    end
    
    local baseDir = _G.DVR_COPYPASTA_SAVE_DIR
    if not baseDir then
        -- Try to read from config if script is run via keyboard shortcut (bypassing UI)
        local appdata = _G.COPY_PASTA_BASE_DIR .. "/"
        local configPath = appdata .. "config.lua"
        local f = io.open(configPath, "r")
        if f then
            local content = f:read("*a")
            f:close()
            local parsed_path = content:match('saveDir%s*=%s*%[%[(.-)%]%]') or content:match('return%s+"(.-)"')
            if parsed_path and verifyDir(parsed_path) then
                baseDir = parsed_path
            end
            local parsed_color = content:match('pasteColor%s*=%s*["\'](.-)["\']')
            if parsed_color and not _G.DVR_COPYPASTA_PASTE_COLOR then
                _G.DVR_COPYPASTA_PASTE_COLOR = parsed_color
            end
        end
    end
    
    if not baseDir or not verifyDir(baseDir) then
        baseDir = defaultBaseDir
    end
    
    local projectName = project:GetName() or "Unknown Project"
    local timelineName = "No Timeline"
    if timeline then
        timelineName = timeline:GetName()
    end
    
    local current_page = resolve:GetCurrentPage()
    local pageNames = {
        media = "Media Page",
        cut = "Cut Page",
        edit = "Edit Page",
        fusion = "Fusion Page",
        color = "Color Page",
        fairlight = "Fairlight Page",
        deliver = "Deliver Page"
    }
    local pageName = pageNames[current_page] or "Unknown Page"
    local fullPageName = pageName
    
    -- Clean strings for valid folder paths
    local function cleanFilename(name)
        return name:gsub('[<>:"/\\\\|?*]', '_')
    end
    
    local safeProject = cleanFilename(projectName)
    local safeTimeline = cleanFilename(timelineName)
    local safePage = cleanFilename(pageName)
    
    local save_dir = baseDir .. "/" .. safeProject .. "/" .. safeTimeline .. "/" .. safePage
    
    -- Create nested directories
    os.execute('mkdir -p "' .. save_dir .. '" 2>/dev/null')
    
    -- Generate a unique filename for image fallback
    local timestamp = os.date("%Y%m%d_%H%M%S")
    local filename = "clipboard_" .. timestamp .. "_img.png"
    local filepath = save_dir .. "/" .. filename
    
    local filepaths = {}
    
    local safe_filepath = filepath
    
    -- 2. Auto Analyze Clipboard via macOS AppleScript
    -- We write a small helper apple script to a temp file and execute it, because passing massive multiline scripts via io.popen can have escaping issues
    local script_path = os.getenv("HOME") .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Support/Fusion/Scripts/Utility/dvr_copypasta_preview/paste_helper.scpt"
    local sf = io.open(script_path, "w")
    if sf then
        sf:write('use framework "AppKit"\n')
        sf:write('set pb to current application\'s NSPasteboard\'s generalPasteboard()\n')
        sf:write('set fileURLs to pb\'s readObjectsForClasses:{current application\'s NSURL} options:(missing value)\n')
        sf:write('if (fileURLs is not missing value) and ((fileURLs\'s |count|()) > 0) then\n')
        sf:write('  repeat with i from 1 to fileURLs\'s |count|()\n')
        sf:write('    set outStr to "FILE:" & ((fileURLs\'s objectAtIndex:(i - 1))\'s path() as string)\n')
        sf:write('    do shell script "echo " & quoted form of outStr\n')
        sf:write('  end repeat\n')
        sf:write('else\n')
        sf:write('  set images to pb\'s readObjectsForClasses:{current application\'s NSImage} options:(missing value)\n')
        sf:write('  if (images is not missing value) and ((images\'s |count|()) > 0) then\n')
        sf:write('    set img to images\'s objectAtIndex:0\n')
        sf:write('    set tiffData to img\'s TIFFRepresentation()\n')
        sf:write('    set bmpRep to current application\'s NSBitmapImageRep\'s imageRepWithData:tiffData\n')
        sf:write('    set pngData to bmpRep\'s representationUsingType:(current application\'s NSPNGFileType) |properties|:(missing value)\n')
        sf:write('    pngData\'s writeToFile:"' .. safe_filepath .. '" atomically:true\n')
        sf:write('    do shell script "echo IMAGE:' .. safe_filepath .. '"\n')
        sf:write('  end if\n')
        sf:write('end if\n')
        sf:close()
    end
    
    local handle = io.popen('osascript "' .. script_path .. '"')
    if handle then
        for line in handle:lines() do
            local fpath = line:match("^FILE:(.+)")
            if fpath then 
                fpath = fpath:gsub("[\r\n]", "")
                local f = io.open(fpath, "r")
                if f then
                    f:close()
                    table.insert(filepaths, fpath)
                else
                    ui_log("⚠️ File does not exist, skipping: " .. fpath)
                end
            end
            
            local ipath = line:match("^IMAGE:(.+)")
            if ipath then 
                ipath = ipath:gsub("[\r\n]", "")
                local f = io.open(ipath, "r")
                if f then
                    f:close()
                    table.insert(filepaths, ipath)
                else
                    ui_log("⚠️ Image file was not saved correctly, skipping: " .. ipath)
                end
            end
        end
        handle:close()
    end
    
    if #filepaths == 0 then
        ShowError("No compatible media or image found in the clipboard.")
        return nil
    end
    
    local function getOrCreateBin(parentFolder, name)
        local subFolders = parentFolder:GetSubFolderList()
        if subFolders then
            for _, folder in ipairs(subFolders) do
                if folder:GetName() == name then
                    return folder
                end
            end
        end
        return mediaPool:AddSubFolder(parentFolder, name)
    end
    
    
    
    local rootFolder = mediaPool:GetRootFolder()
    local masterBin = getOrCreateBin(rootFolder, "📂From Copy Pasta")
    local timelineBin = getOrCreateBin(masterBin, "🗃️ " .. timelineName)
    local targetBin = getOrCreateBin(timelineBin, fullPageName)
    
    mediaPool:SetCurrentFolder(targetBin)
    
    -- 3. Import the file(s) into DaVinci Resolve
    local imported_items = mediaPool:ImportMedia(filepaths)
    if not imported_items or #imported_items == 0 then
        ShowError("Failed to import the copied files into the Media Pool.")
        return nil
    end
    
    for _, item in ipairs(imported_items) do
        if item.SetClipProperty then
            item:SetClipProperty("Alpha mode", "Premultiplied")
        end
    end
    
    if current_page == "fusion" then
        local fusion = resolve:Fusion()
        local comp = fusion.CurrentComp
        if comp then
            -- Lock the composition to prevent the "Open File" dialog from popping up!
            comp:Lock()
            local success, err = pcall(function()
                local loader = comp:AddTool("Loader", -32768, -32768)
                if loader then
                    -- We just assign the first imported item's file path to the Loader (useful for single images)
                    local fusion_path = filepaths[1]:gsub("\\\\", "/")
                    loader.Clip = fusion_path
                end
            end)
            comp:Unlock()
            if not success then
                ui_log("⚠️ Error creating Loader: " .. tostring(err))
            end
            
            ui_log("✅ Successfully pasted into Fusion comp as a Loader node!")
            _G.LAST_PASTED_DIR = save_dir
            return nil
        else
            ui_log("⚠️ Warning: On Fusion page, but no active comp found. Falling back to timeline.")
        end
    end
    
    -- 4. Append to timeline
    if timeline then
        local timecode = timeline:GetCurrentTimecode()
        local framerate = tonumber(project:GetSetting("timelineFrameRate"))
        
        local record_frame = timeline:GetStartFrame()
        
        -- Parse timecode to frames
        local h, m, s, frm = timecode:match("(%d+):(%d+):(%d+)[:;](%d+)")
        if h and m and s and frm then
            h = tonumber(h)
            m = tonumber(m)
            s = tonumber(s)
            frm = tonumber(frm)
            local fps_int = math.floor(framerate + 0.5)
            local drop_frame = (timecode:find(";") ~= nil)
            
            local total_minutes = h * 60 + m
            local total_frames = (total_minutes * 60 + s) * fps_int + frm
            
            if drop_frame and (fps_int == 30 or fps_int == 60) then
                local drop_frames = 2
                if fps_int == 60 then drop_frames = 4 end
                local drops = drop_frames * (total_minutes - math.floor(total_minutes / 10))
                total_frames = total_frames - drops
            end
            record_frame = total_frames
        end
    
        local track_count = timeline:GetTrackCount("video")
        local target_track = nil
        
        if track_count == 0 then
            timeline:AddTrack("video")
            target_track = 1
        else
            local fps_int = math.floor(framerate + 0.5)
            local paste_duration = fps_int * 5 -- default image duration is 5 seconds
            for i = 1, track_count do
                local items = timeline:GetItemListInTrack("video", i)
                local collision = false
                if items then
                    for _, item in pairs(items) do
                        if type(item) == "userdata" and item.GetStart then
                            local startFrame = item:GetStart()
                            local endFrame = item:GetEnd()
                            -- Check if the 5-second footprint overlaps with any existing clip
                            if record_frame < endFrame and (record_frame + paste_duration) > startFrame then
                                collision = true
                                break
                            end
                        end
                    end
                end
                
                if not collision then
                    target_track = i
                    break
                end
            end
            
            if not target_track then
                timeline:AddTrack("video")
                target_track = track_count + 1
            end
        end
    
        local clip_infos = {}
        for i, item in ipairs(imported_items) do
            table.insert(clip_infos, {
                mediaPoolItem = item,
                trackIndex = target_track,
                recordFrame = record_frame
            })
        end
        
        local res = mediaPool:AppendToTimeline(clip_infos)
        if res then
            local targetColor = _G.DVR_COPYPASTA_PASTE_COLOR or "Default Color"
            if targetColor ~= "Default Color" and type(res) == "table" then
                for _, item in ipairs(res) do
                    if type(item) == "userdata" and item.SetClipColor then
                        item:SetClipColor(targetColor)
                    end
                end
            end
            
            ui_log("✅ Successfully pasted " .. #imported_items .. " item(s) to the timeline at track " .. target_track .. ", frame " .. record_frame .. "!")
            if targetColor ~= "Default Color" then
                ui_log("  > Applied clip color: " .. targetColor)
            end
            _G.LAST_PASTED_DIR = save_dir
        else
            ShowError("Failed to append image to the timeline.")
        end
    else
        ShowError("Image was imported to the Media Pool, but no active timeline was found to append it to.")
    end
    
end

-- Event handlers

window.On.BtnBrowse.Clicked = function(ev)
    -- Use DaVinci Resolve's beautiful native dark-themed folder picker instead of the ancient Windows tree!
    local result = fusion:RequestDir(itm.SavePathEdit.Text)
    if result and result ~= "" then
        -- Normalize the path slashes
        result = result:gsub("\\\\", "/")
        result = result:gsub("/$", "")
        
        if result ~= "" then
            itm.SavePathEdit.Text = result
            ui_log("📂 Selected path. Click 'Save Preset' to keep.")
        end
    end
end

window.On.BtnOpenFolder.Clicked = function(ev)
    local path = itm.SavePathEdit.Text
    if path and path ~= "" then
        os.execute('open "' .. path .. '"')
        ui_log("📂 Opened folder in Finder.")
    end
end

window.On.BtnYouTube.Clicked = function(ev)
    os.execute('open "https://www.youtube.com/@alokvideoeditornp"')
    ui_log("📺 Opened YouTube Channel")
end


local function RefreshPresets(selectName)
    itm.PresetCombo:Clear()
    itm.PresetCombo:AddItem("--- Custom ---")
    local presets = GetPresetList()
    local toSelect = 0
    for i, p in ipairs(presets) do
        itm.PresetCombo:AddItem(p)
        if p == selectName then
            toSelect = i
        end
    end
    itm.PresetCombo.CurrentIndex = toSelect
end

RefreshPresets(loadedPreset)

window.On.PresetCombo.CurrentIndexChanged = function(ev)
    local idx = itm.PresetCombo.CurrentIndex
    local name = itm.PresetCombo.CurrentText
    if idx > 0 and name ~= "--- Custom ---" then
        local path, color = LoadPreset(name)
        if path then
            itm.SavePathEdit.Text = path
            for i=0, #colorData-1 do
                if colorData[i+1][1] == color then
                    itm.ColorCombo.CurrentIndex = i
                    break
                end
            end
            ui_log("📂 Loaded Preset: " .. name)
            SaveConfig(itm.SavePathEdit.Text, itm.ColorCombo.CurrentText, name)
        end
    else
        SaveConfig(itm.SavePathEdit.Text, itm.ColorCombo.CurrentText, "--- Custom ---")
    end
end

window.On.BtnSavePreset.Clicked = function(ev)
    saveItm.PresetNameEdit.Text = ""
    saveWin:Show()
end

saveWin.On.BtnConfirmSave.Clicked = function(ev)
    local name = saveItm.PresetNameEdit.Text
    if name and name ~= "" then
        name = name:gsub('^%s*(.-)%s*$', '%1') -- trim
        name = name:gsub('[\\\\/:*?"<>|]', "_")
        if name ~= "" then
            SavePreset(name, itm.SavePathEdit.Text, itm.ColorCombo.CurrentText)
            ui_log("✅ Preset Saved: " .. name)
            saveWin:Hide()
            RefreshPresets(name)
            SaveConfig(itm.SavePathEdit.Text, itm.ColorCombo.CurrentText, name)
        end
    end
end

saveWin.On.BtnCancelSave.Clicked = function(ev)
    saveWin:Hide()
end

saveWin.On.SavePresetWin_v2.Close = function(ev)
    saveWin:Hide()
end

window.On.BtnShowDelete.Clicked = function(ev)
    delItm.DelPresetCombo:Clear()
    local presets = GetPresetList()
    if #presets == 0 then
        ui_log("❌ No presets to delete.")
        return
    end
    for _, p in ipairs(presets) do
        delItm.DelPresetCombo:AddItem(p)
    end
    delWin:Show()
end

delWin.On.BtnConfirmDel.Clicked = function(ev)
    local name = delItm.DelPresetCombo.CurrentText
    if name and name ~= "" then
        local filePath = presetDir .. name .. ".lua"
        os.remove(filePath)
        ui_log("🗑️ Deleted Preset: " .. name)
        delWin:Hide()
        
        local currentMain = itm.PresetCombo.CurrentText
        if currentMain == name then
            currentMain = "--- Custom ---"
        end
        RefreshPresets(currentMain)
    end
end

delWin.On.BtnCancelDel.Clicked = function(ev)
    delWin:Hide()
end

delWin.On.DeletePresetWin_v2.Close = function(ev)
    delWin:Hide()
end

window.On.ColorCombo.CurrentIndexChanged = function(ev)
    local cleanColor = itm.ColorCombo.CurrentText
    UpdateColorPreview(cleanColor)
    
    ui_log("🎨 Selected paste color to " .. cleanColor)
end





window.On.BtnCopy.Clicked = function(ev)
    itm.BtnCopy.Text = "⏳  Copying..."
    itm.BtnCopy.Enabled = false
    ui_log("▶ Running Copy Frame...")
    
    ExecuteCopyFrame(itm.ChkAutoExplore.Checked)
    
    if _G.LAST_COPIED_FRAME then
        local fixed_path = _G.LAST_COPIED_FRAME:gsub("\\\\", "/")
        -- Deep Fix: Use HTML to strictly constrain the image height so it cannot shatter the UI layout engine
        itm.PreviewLabel.Text = "<html><body><center><img src='file:///" .. fixed_path .. "' height='85'></center></body></html>"
        itm.PreviewLabel.StyleSheet = "border: 1px solid #40405A; background-color: #05050A;"
    end
    
    itm.BtnCopy.Text = "📷  Copy Frame to Clipboard"
    itm.BtnCopy.Enabled = true
end

window.On.BtnPaste.Clicked = function(ev)
    itm.BtnPaste.Text = "⏳  Pasting..."
    itm.BtnPaste.Enabled = false
    ui_log("▶ Running Paste Image...")
    
    ExecutePasteImage()
    
    itm.BtnPaste.Text = "📥  Paste Image to Timeline"
    itm.BtnPaste.Enabled = true
end

window.On.BtnClear.Clicked = function(ev)
    itm.Log.Text = ""
    sessionLog = ""
end

window.On.CopyPastaUIAA.Close = function(ev)
    local temp_dir = _G.COPY_PASTA_BASE_DIR .. "/dvr_copypasta_preview"
    os.execute('rm -rf "' .. temp_dir .. '" 2>/dev/null')
    dispatcher:ExitLoop()
end

-- Show the window
window:Show()
window:Resize({ WIN_W, WIN_H })
dispatcher:RunLoop()
window:Hide()
